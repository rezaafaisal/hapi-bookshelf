let books = [
  {
    id: 1,
    judul: "Buku Baru",
    penulis: "Anggara",
    tahun: 2019,
    kategori: "Buku",
    created_at: "2022-02-12",
    updated_at: "2022-02-12"
  }
];

export default books